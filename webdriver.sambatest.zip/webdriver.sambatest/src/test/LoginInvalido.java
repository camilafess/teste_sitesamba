package br.com.samba.webdriverJava.webdriver.sambatest;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LoginInvalido {
	 FirefoxDriver driver = new FirefoxDriver();
	  driver.get("http://web1.qa.sambatech.com:10000/auth/login");
	  
	  driver.findElement(By.id("email")).sendKeys("testesamba@teste.com.br");
	  driver.findElement(By.id("password")).sendKeys("123456789");
	  driver.findElement(By.id("login")).click("Entrar");
	  driver.findElement (By.id("password_incorrect")).sendKeys("Email ou senha incorretos.")
	  
} 
