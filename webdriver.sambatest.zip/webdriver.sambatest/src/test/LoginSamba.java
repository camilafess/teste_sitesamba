package br.com.samba.webdriverJava.webdriver.sambatest;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.junit.Test;

  @Test
  public class LoginSambaTest() {
  FirefoxDriver driver = new FirefoxDriver();
  driver.get("http://web1.qa.sambatech.com:10000/auth/login");
  
  driver.findElement(By.id("email")).sendKeys("avaliacao_qa_samba@sambatech.com.br");
  driver.findElement(By.id("password")).sendKeys("123456789");
  driver.findElement(By.id("login")).click();
}


